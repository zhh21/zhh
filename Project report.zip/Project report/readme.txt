# Cloud-Based Hotel Management System

## Overview
This project explores cloud-native architectures applied to a hotel management system.

## Report
The project report is written in LNCS format using LaTeX and located in the `report/` directory.

## Code
All backend code is implemented by the author and can be found in the `backend/` directory.

## References
All references are managed using BibTeX (`report/references.bib`).

